package com.example.projetocompras;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    double vmaca,vbanana,vpera,vuva, vtotal;
    CheckBox cb_maca,cb_banana,cb_pera,cb_uva;
    EditText editTxt_maca,editTxt_banana,editTxt_pera,editTxt_uva;
    TextView  resultado;
    Button btn_Calcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cb_maca = (CheckBox) findViewById(R.id.cb_maca);
        cb_banana = (CheckBox) findViewById(R.id.cb_banana);
        cb_pera = (CheckBox) findViewById(R.id.cb_pera);
        cb_uva = (CheckBox) findViewById(R.id.cb_uva);

        editTxt_maca = (EditText) findViewById(R.id.editTxtNumber1);
        editTxt_banana = (EditText) findViewById(R.id.editTxtNumber2);
        editTxt_pera = (EditText) findViewById(R.id.editTxtNumber3);
        editTxt_uva = (EditText) findViewById(R.id.editTxtNumber4);

        vmaca = 0.25;
        vbanana = 0.20;
        vpera = 0.15;
        vuva = 0.10;

        cb_maca.setText(cb_maca.getText().toString() + vmaca);
        cb_banana.setText(cb_banana.getText().toString() + vbanana);
        cb_pera.setText(cb_pera.getText().toString() + vpera);
        cb_uva.setText(cb_uva.getText().toString() + vuva);

        btn_Calcular = (Button)findViewById(R.id.button);

        resultado = (TextView)findViewById(R.id.resultado);

    }

    public void calculo(View v){

        vtotal = 0 ;

        if (cb_maca.isChecked()){
            vtotal += vmaca * Double.parseDouble(editTxt_maca.getText().toString());
        }
        if (cb_banana.isChecked()){
            vtotal += vbanana * Double.parseDouble(editTxt_banana.getText().toString());
        }
        if (cb_pera.isChecked()){
            vtotal += vpera * Double.parseDouble(editTxt_pera.getText().toString());
        }
        if (cb_uva.isChecked()){
            vtotal += vuva * Double.parseDouble(editTxt_uva.getText().toString());
        }

        resultado.setText("Valor total: R$ "+String.valueOf(vtotal));

        Toast.makeText(this,"calculado",Toast.LENGTH_LONG).show();

        AlertDialog.Builder cxMsg = new AlertDialog.Builder(this);
        cxMsg.setMessage("Calculado com sucesso");
        cxMsg.setNeutralButton("Ok",null);
        cxMsg.show();
    }

}