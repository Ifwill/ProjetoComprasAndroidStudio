package com.example.projetocompras;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Double vmaca,vbanana,vpera,vuva;
    CheckBox cb_maca,cb_banana,cb_pera,cb_uva;
    EditText editTxtNumber1,editTxtNumber2,editTxtNumber3,editTxtNumber4;
    TextView  resultado;
    Button btn_Calcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cb_maca = findViewById(R.id.cb_maca);
        cb_banana = findViewById(R.id.cb_banana);
        cb_pera = findViewById(R.id.cb_pera);
        cb_uva = findViewById(R.id.cb_uva);

        editTxtNumber1 = findViewById(R.id.editTxtNumber1);
        editTxtNumber2 = findViewById(R.id.editTxtNumber2);
        editTxtNumber3 = findViewById(R.id.editTxtNumber3);
        editTxtNumber4 = findViewById(R.id.editTxtNumber4);

        btn_Calcular = findViewById(R.id.button);

        resultado = findViewById(R.id.resultado);


    }
}